

require 'aws-sdk'
module Dji
  module FlyRecord
    module S3FileDownload
      extend self

      def download(filename, s3_path)
        return if s3_path.blank?

        s3 = Aws::S3::Client.new(
          region: 'us-east-1',
          credentials: Aws::Credentials.new(
            Settings.flight_record.s3_key_id,
              Settings.flight_record.s3_secret_key
          )
        )

        #TODO 添加未下载到文件的错误捕捉
        #puts filename
        File.open(filename, 'wb') do |file|
          s3.get_object({ bucket: Settings.flight_record.s3_bucket_name, key: s3_path}, {target: file})
        end
      end

      def get_s3_path(s3_path_root, s3_path_key, file_name)
        if s3_path_key.blank?
          Rails.logger.info "no s3path_key for #{file_name}"
          ''
        elsif s3_path_key.include?('/')
          s3_path_key
        else
          s3_path_root + s3_path_key + '/' + file_name + '.zip'
        end
      end

      #解压缩文件
      def unzip_file(file_path)
        return unless File.exist?(file_path)
        file_name = File.basename(file_path, '.zip')

        Dir.chdir File.dirname(file_path) do
          File.open(file_path) do |cf|
            begin
              zi = Zlib::Inflate.new
              File.open(file_name, 'wb') do |ucf|
                ucf << zi.inflate(cf.read)
              end
              zi.close
            rescue =>
              cf.close
            end
          end
        end

        File.join(File.dirname(file_path), file_name)
      end
    end
  end
end
