

module Dji
  module FlyRecord
    class RecordDataParse
      def self.parse_data(file_name)
        File.open(file_name, 'r') do |file|
          begin
            r = Dji::FlyRecord::RecordDataPrefix.read(file)
            @version = r.detail_version
            p r.detail_version
          rescue
            file.close
          end
        end

        get_parse_instance(@version, file_name)
      end

      def self.get_parse_instance(version, file_name)
        parse_instance = nil
        File.open(file_name, 'r') do |file|
          begin
            case version

            when 1 then
              parse_instance = Dji::FlyRecord::RecordDataV1.read(file)
            when 2 then
              parse_instance = Dji::FlyRecord::RecordDataV2.read(file)
            when 3 then
              parse_instance = Dji::FlyRecord::RecordDataV3.read(file)
            when 4 then
              parse_instance = Dji::FlyRecord::RecordDataV4.read(file)
            when 5 then
              parse_instance = Dji::FlyRecord::RecordDataV5.read(file)
            when 6 then
              parse_instance = Dji::FlyRecord::RecordDataV6.read(file)
            when 7 then
              parse_instance = Dji::FlyRecord::RecordDataV7.read(file)
            when 8 then
              parse_instance = Dji::FlyRecord::RecordDataV7.read(file)
            when 9 then
              parse_instance = Dji::FlyRecord::RecordDataV9.read(file)
              else
              parse_instance = Dji::FlyRecord::RecordDataV9.read(file)
              Rails.logger.info "飞行记录版本号高于已知版本，默认采用最高版本解析 filename=#{file_name} version=#{version}"
            end
          rescue => e
            file.close
            Rails.logger.info e.to_s
          end

        end
        parse_instance
      end
    end
  end
end
