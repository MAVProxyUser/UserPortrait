

# require 'aliyun-sdk'
module Dji
  module FlyRecord
    module OssFileDownload
      extend self

      def download(filename, oss_path)
        return if oss_path.blank?

        oss = Aliyun::OSS::Client.new(
          endpoint: Settings.flight_record.aliyun_host,
          access_key_id: Settings.flight_record.oss_key_id,
          access_key_secret: Settings.flight_record.oss_secret_key)

        #TODO 添加未下载到文件的错误捕捉
        File.open(filename, 'wb') do |file|
          oss.get_object({ bucket: Settings.flight_record.oss_bucket, key: oss_path}, {target: file})
        end
      end

      #解压缩文件
      def unzip_file(filename, filepath)
        return unless File.exist?(filepath)

        File.open(filepath) do |cf|
          zi = Zlib::Inflate.new
          File.open(filename, 'wb') do |ucf|
            #TODO 添加解压出错的捕捉
            ucf << zi.inflate(cf.read)
          end
          zi.close
        end
      end
    end
  end
end
