

module Dji
  module FlyRecord
    class RecordDataV1 < BinData::Record
      uint64le :detail_offset

      uint16le :detail_length

      uint8  :detail_version

      uint8  :special_use
      #数据记录主体
      skip   length: lambda { body_length }
      #array  :body, :type=>:uint8, :initial_length => lambda {body_length}
      array  :info, initial_length: 1 do
        #记录地图信息名称:路
        string :road,                read_length: 20
        #记录地图信息名称:区
        string :district,            read_length: 20
        #记录地图信息名称:市
        string :locality,            read_length: 20
        #记录地图信息名称:省
        string :administrative_area, read_length: 20
        #该记录是否被收藏： 1. 收藏 2. 未收藏 新生成是 2 ，未收藏
        uint8   :is_favourite
        #该记录是否点开过：1:没点开  2.点开过了（new 的标记会消失） 新生成是1
        uint8   :is_new
        #该记录是否upload 0:不用upload 1:新增的 2:修改的（服务器有但是还要上传） 新增是1，修改是2，每次上传完是0. 同步时是0就不用上传
        bit2   :file_uploaded
        #0:文件还没同步到服务器上 1:文件同步到服务器
        bit1   :file_synced
        #0:info还没同步到服务器上 1:info同步到服务器
        bit1   :info_synced
        # reserved
        bit4   :reserved_upload
        #统计osd数据个数。该记录有recordLineCount个osd采样数据
        int32le  :osd_count
        #默认数值12345，如果不对，说明数据错位，ios会调recover，recover失败删掉该记录。
        int32le  :detail_checksum
        #这条记录发生的时间戳信息，单位ms(0.001s) 毫秒
        int64le  :timestamp
        #该条记录发生时的经度
        double_le :longitude
        #该条记录发生时的纬度
        double_le :latitude
        #飞行轨迹距离，单位M米
        float_le  :total_distance
        #飞行时长，单位ms (毫秒)
        int32le :total_time
        #最大高度，单位m
        float_le  :max_height
        #最大水平速度 m/s
        float_le  :max_horizon_speed
        #最大垂直速度 m/s
        float_le  :max_vertical_speed
        #拍照次数
        int32le  :capture_num
        #视频时长单位  s 秒
        int64le  :video_time
        #Moment 4张大图的字节长度
        array  :moment_image_len, type: :int32le, initial_length: 4
        #Momen4张小图的字节长度
        array  :moment_shrinkimage_len, type: :int32le, initial_length: 4
        #4张图经度
        array  :moment_longitude, type: :double_le, initial_length: 4
        #4张图纬度
        array  :moment_latitude, type: :double_le, initial_length: 4
        #目前ios是-1，安卓是0 analysisFileOffsetFromHead
        int64le :analysis_offset
        # 用户email的md5，生成是”000…0000”,16个’0’， 同步以后该16位字符串存的是md5("email_djipilot")的16位md5值。
        # 注意：对email做md5的时候有个后缀”_djipilot”
        string :useremail_md5, read_length: 16
        #飞行器的版号 SN
        array  :board_num, type: :uint8, initial_length: 10
        # FlightRecord_Inspire=1, FlightRecord_Phantom3C=2, FlightRecord_Phantom3S=3,
        # FlightRecord_Phantom3X=4, FlightRecord_Longan=5, FlightRecord_N1=6,
        # FlightRecord_Phantom4=7, FlightRecord_LB2=8, FlightRecord_Inspire1Pro=9,
        # A3飞控 10, M600 11, wifi 3x 12, 小飞机 13, Flir相机独立的产品 14, inspire raw 15, android a2+lb2 16, inspire 2 17, x5 18, x5r 19, x3.5 20, 小飞机低端版 21
        # 手机OSMO 22.
        uint8  :drone_type
        #飞行器名称，用户起的
        string :aircraft_name, read_length: 32
        #飞行器激活时间戳，单位ms
        int64le :activation_timestamp
        #相机版号 SN
        array  :camera_sn, type: :uint8, initial_length: 10
        #遥控器版号 SN
        array  :rc_sn, type: :uint8, initial_length: 10
        #电池版号SN
        array  :battery_sn, type: :uint8, initial_length: 10
        #App 版号.第一位区分app ios还是安卓 1:ios, 2:android,后三位对应app版本号
        array  :app_version, type: :uint8, initial_length: 4
        #起飞海拔高度，单位m
        float_le :takeoff_altitude
        # isShared:1;//是否分享
        bit1   :is_shared
        # 精彩时刻显示index,如果单张显示的moment的话，显示哪张(0-3)
        bit2   :display_moment_index
        # reserved
        bit5   :reserved_share
        # reserved 保留43位
        string :reserved, read_length: 43
      end

      def body_length
        detail_offset - 12
      end

      def get_road
        info[0].road.force_encoding('UTF-8').gsub("\000", '')
            .encode('UTF-8', invalid: :replace, replace: '?').each_char.select { |c| c.bytes.count < 4 }.join
      end

      def get_district
        info[0].district.force_encoding('UTF-8').gsub("\000", '')
            .encode('UTF-8', invalid: :replace, replace: '?').each_char.select { |c| c.bytes.count < 4 }.join
      end

      def get_locality
        info[0].locality.force_encoding('UTF-8').gsub("\000", '')
            .encode('UTF-8', invalid: :replace, replace: '?').each_char.select { |c| c.bytes.count < 4 }.join
      end

      def get_administrative_area
        info[0].administrative_area.force_encoding('UTF-8').gsub("\000", '')
            .encode('UTF-8', invalid: :replace, replace: '?').each_char.select { |c| c.bytes.count < 4 }.join
      end

      def get_aircraft_name
        info[0].aircraft_name.force_encoding('UTF-8').gsub("\000", '')
            .encode('UTF-8', invalid: :replace, replace: '?').each_char.select { |c| c.bytes.count < 4 }.join
      end

      def get_camera_sn
        sn = ''
        info[0].camera_sn.each do |char|
          if char > (31) && char < (127)
            sn += char.chr
          else
            sn += char.to_s
          end        end
        sn.strip
      end

      def get_rc_sn
        sn = ''
        info[0].rc_sn.each do |char|
          if char > (31) && char < (127)
            sn += char.chr
          else
            sn += char.to_s
          end        end
        sn.strip
      end

      def get_battery_sn
        sn = ''
        info[0].battery_sn.each do |char|
          if char > (31) && char < (127)
            sn += char.chr
          else
            sn += char.to_s
          end        end
        sn.strip
      end

      def get_board_num
        sn = ''
        info[0].board_num.each do |char|
          if char > (31) && char < (127)
            sn += char.chr
          else
            #sn += char.to_s
          end        end
        sn.strip
      end

      def get_md5
        Digest::MD5.hexdigest(info[0].to_binary_s)
      end

      # #获取一条飞行记录的电池最高温度,最低温度,及循环次数
      # def get_body_info
      #   tmp_body = body
      #
      #   cnt = 0
      #   highest_temperature = 0
      #   lowest_temperature = 0
      #   circle_time = 0
      #   #puts "body_size #{tmp_body.length}"
      #   while tmp_body.length > 0
      #     # #puts "before #{tmp_body[0]}"
      #     index_end = tmp_body.find_index(255)
      #     break if index_end.nil?
      #     if tmp_body[0] == 7 && tmp_body[1] + 3 == index_end + 1 && tmp_body[1] + 3 == 38
      #       cnt += 1
      #
      #
      #       circle_time = tmp_body[10] + tmp_body[11]*256 if circle_time == 0
      #       if (tmp_body[34] + tmp_body[35]*256) * 0.1 - 273.15 > highest_temperature || cnt == 1
      #         highest_temperature = (tmp_body[34] + tmp_body[35]*256) * 0.1 - 273.15
      #       end
      #
      #       if (tmp_body[34] + tmp_body[35]*256) * 0.1 - 273.15 < lowest_temperature || cnt == 1
      #         lowest_temperature = (tmp_body[34] + tmp_body[35]*256) * 0.1 - 273.15
      #       end
      #       #puts "count #{cnt} length #{index_end + 1}, #{tmp_body[1] + 3}"
      #       #puts "circle time #{tmp_body.[](8,6)}"
      #       #puts "temperature #{(tmp_body[34] + tmp_body[35]*256) * 0.1 - 273.15}"
      #     end
      #     tmp_body = tmp_body.[](index_end + 1, tmp_body.length - index_end - 1)
      #     # #puts "obj length #{tmp_body.length}"
      #     # #puts "after #{tmp_body[0]}"
      #   end
      #   [lowest_temperature, highest_temperature, circle_time]
      # end
    end
  end
end
