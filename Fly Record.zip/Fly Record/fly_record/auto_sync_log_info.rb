

require "#{Rails.root}/lib/dji/fly_record/record_data_v1.rb"
require "#{Rails.root}/lib/dji/fly_record/record_data_v2.rb"
require "#{Rails.root}/lib/dji/fly_record/record_data_v3.rb"
require "#{Rails.root}/lib/dji/fly_record/record_data_v4.rb"
require "#{Rails.root}/lib/dji/fly_record/record_data_v5.rb"
require "#{Rails.root}/lib/dji/fly_record/record_data_v6.rb"

module Dji
  module FlyRecord
    # include Dji::FlyRecord::RecordDataV1
    # include Dji::FlyRecord::RecordDataV2
    # include Dji::FlyRecord::RecordDataV3
    # include Dji::FlyRecord::RecordDataV4
    # include Dji::FlyRecord::RecordDataV5
    # include Dji::FlyRecord::RecordDataV6

    class AutoSyncLogInfo < BinData::Record
      endian :little
      array :body, read_until: :eof do
        string :file_name,  read_length: 21
        uint8  :version
        uint8  :special_use
        uint16 :info_length
        choice :info,     selection: :version do
          record_data_v1      1
          record_data_v2      2
          record_data_v3      3
          record_data_v4      4
          record_data_v5      5
          record_data_v6      6
        end
      end
    end
  end
end
