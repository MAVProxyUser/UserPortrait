

module Dji
  module FlyRecord
    class RecordDataPrefix < BinData::Record
      endian :little
      uint64le :detail_offset
      uint16le :detail_length
      uint8  :detail_version
      uint8  :special_use
    end
  end
end
